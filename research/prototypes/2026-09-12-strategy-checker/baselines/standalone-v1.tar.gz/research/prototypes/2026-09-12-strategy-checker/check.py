"""Replay checker tests, CLI tests, and normal/optimized demo agreement."""

import json
import subprocess
import sys
from hashlib import sha256
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def command(args, cwd=HERE):
    completed = subprocess.run(args, cwd=cwd, capture_output=True, text=True, timeout=120, check=False)
    if completed.returncode:
        raise RuntimeError(completed.stdout + completed.stderr)
    return completed.stdout


def main():
    for flags in (["-B"], ["-B", "-O"]):
        command([sys.executable, *flags, "-m", "unittest", "test_checker"])
    normal = command([sys.executable, "-B", "demo.py"])
    optimized = command([sys.executable, "-B", "-O", "demo.py"])
    if normal != optimized:
        raise RuntimeError("normal and optimized demo records differ")
    demo = json.loads(normal)
    paths = [ROOT / "src/orbitsynthesis/strategy_checker.py",
             ROOT / "scripts/check_controller.py", ROOT / "LICENSE", ROOT / "README.md"]
    paths += sorted(p for p in HERE.iterdir() if p.is_file() and p.name != "replay.json")
    paths += sorted((ROOT / "examples/controllers").iterdir())
    result = {"schema": "orbitsynthesis/finite-controller-replay/v1", "status": "PASS",
              "exhaustive_graph_cases_per_mode": 33100, "seeded_product_cases_per_mode": 300,
              "normal_optimized_agree": True, "demo": demo,
              "known_faults_detected": ["unchecked_contract_pin", "skipped_safety",
                                        "omitted_recurrence", "ignored_second_input"],
              "source_sha256": {str(p.relative_to(ROOT)): sha256(p.read_bytes()).hexdigest()
                                for p in paths},
              "tau_execution_performed": False, "runtime_refinement_verified": False,
              "patent_clearance_established": False}
    (HERE / "replay.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print("PASS: 33,100 exhaustive models and 300 product cases per mode; CLI and counterexamples checked.")
    print("Normal and python -O demo records agree. Wrote replay.json.")


if __name__ == "__main__":
    main()
