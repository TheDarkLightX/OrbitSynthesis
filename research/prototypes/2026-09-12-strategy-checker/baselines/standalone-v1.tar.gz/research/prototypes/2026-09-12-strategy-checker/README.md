# Practical finite-controller checking

The implemented tool is [`scripts/check_controller.py`](../../../scripts/check_controller.py).
Start with the [runnable examples](../../../examples/controllers/README.md).
It checks a supplied controller against an independently pinned finite contract
and returns either acceptance, a finite safety counterexample, or a prefix and
repeating cycle showing starvation.

Implemented scope: input-first finite Mealy controllers, safety, and conjunctions
of recurring-progress goals. There is no input fairness assumption. The tool
does not synthesize a controller or establish that a rejected contract has no
solution.

## Evidence

From the repository root:

```bash
python3 research/prototypes/2026-09-12-strategy-checker/check.py
```

The gate compares every transition table with one through three plant states,
two inputs and one output against an independently written matrix-closure
oracle, including forbidden transitions and every possible single recurrence
set: 33,100 cases. It also checks 300 seeded cases with controller memory,
multiple outputs and two goals, schema and pin failures, witness validity,
immutable results, and CLI exit codes. Normal and optimized Python runs must
produce identical demo records.

Four deliberately faulty checker copies establish that the retained negatives
detect omitted contract binding, omitted safety checking, omitted recurrence
checking, and omission of the second environment input. The probe edits only
temporary copies of this independently authored checker.

The fair arbiter has four reachable product states, sixteen checked transitions,
and two recurring-progress goals. The priority arbiter fails on this sequence:

```text
input 3 (both requests) -> grant request 0; request 1 stays pending
repeat input 1         -> grant request 0; request 1 stays pending forever
```

These are original fixtures. They are not Tau-produced controllers or native
reproductions of the Tau issue. See [`replay.json`](replay.json) for the source
hashes and detailed model results after running the gate.

## Remaining integration work

| Gate | Current status |
| --- | --- |
| Independently pinned finite contract and strategy | Implemented |
| Safety and recurring-progress checking | Implemented for the declared finite model |
| Actionable input/output counterexamples | Implemented |
| Tau syntax/HOA to finite-contract translation | Unimplemented; must preserve initial state, timing, domains and goals |
| Tau or another producer supplying real candidates | Unimplemented adapter |
| Generated executable versus accepted strategy | Unimplemented; still required to catch code-generation errors |
| Operational admission, side effects, deployment | Unimplemented |

The useful first workflow is local research/noncommercial evaluation of small
controller tables. Any later native Tau adapter will use a separately obtained
installation within the current Tau license's permitted scope. This packet
uses OrbitSynthesis's existing MIT license and does not bundle Tau. The
[provenance note](PROVENANCE.md) records the exact boundary.
