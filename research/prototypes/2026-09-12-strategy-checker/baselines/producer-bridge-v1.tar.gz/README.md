# OrbitSynthesis

Mathematical research on reactive synthesis over infinite logical structures, beginning from Ohad Asor's work on Tau, atomless Boolean algebras, and `ocLTL` over effectively presented omega-categorical structures.

## Research rule

This repository separates **proved**, **computationally checked**, **conjectured**, **refuted**, and **unknown** claims. Literature claims must have provenance. Failed conjectures and minimal counterexamples are first-class research outputs.

## Proof philosophy

Prefer proofs that expose the structural reason a statement is true: symmetry, quotient, invariant, universal property, canonical representation, or another mechanism that explains the result rather than merely certifying it. This is the project's Noether-style criterion for explanatory proofs.

## Initial frontier

The first program studies three questions that arise directly from the current literature:

1. **Exact type-space structure.** Understand complete type spaces and their growth in concrete omega-categorical theories, starting with the countable atomless Boolean algebra.
2. **Direct fixed points.** Determine when synthesis fragments can be solved directly by first-order fixed-point iteration over an omega-categorical structure, avoiding full type enumeration and propositionalization.
3. **Specification-generated compression.** Quantify exactly how much of a complete type a given specification actually needs, following the optimization in Asor's `ocLTL` construction.

The repository will not assume that a Myhill-Nerode-style minimization theorem for synthesis exists. That connection remains a candidate conjecture to test against the adjacent register/nominal-automata literature.

## Status

The standalone kernel includes source-bound certificates for finite prime-field
relations and reusable verified membership. Current capabilities and evidence:

| Capability | Evidence and scope | Entry point |
|---|---|---|
| Affine equations or explicit nonaffine fallback | Exact source-bound verification; 800 small relations and growing-family replay | [`affine_dispatch.py`](src/orbitsynthesis/affine_dispatch.py) |
| Split-kernel and affine-fiber certificates | Lean semantic theorems, finite calibration, independent Python replay | [`certificate packets`](research/tournaments/2026-08-21-affine-relation-certificate/REPORT.md) |
| Fixed-anchor Mal'tsev closure | Lean equivalence over additive commutative groups; 946-relation independent replay | [`AnchoredMaltsev.lean`](formal/OrbitSynthesis/AnchoredMaltsev.lean) |
| Runtime and memory comparison | Local measurements against a prebuilt table index; no universal speed claim | [`improvement report`](research/improvements/2026-09-05-affine-runtime/REPORT.md) |
| Three living paper drafts | Explicit theorem/candidate labels and source-hash audit | [`paper portfolio`](paper/PAPER_PORTFOLIO.md) |

## Try verified membership

From the repository root, using Python 3.12 or later:

```bash
PYTHONPATH=src python3 - <<'PY'
from orbitsynthesis.affine_dispatch import (
    emit_certified_affine_dispatch,
    verify_certified_affine_dispatch,
)

# The diagonal relation over the two-element field.
rows = ((0, 0), (1, 1))
artifact = emit_certified_affine_dispatch(rows, modulus=2)
verified = verify_certified_affine_dispatch(artifact, rows)
print(artifact.backend)            # linear_sat
print(verified.solution_count)     # 2
print(verified.contains((1, 1)))    # True
print(verified.contains((0, 1)))    # False
PY
```

Keep and reuse the returned verified handle. General backends build an immutable
row index once. Linear backends evaluate equations. Parsing an artifact does not
verify it; use `verify_certified_affine_dispatch` with the source relation.

## Replay and benchmark

The full gate requires Python 3.12+, `rg`, and the Lean version pinned in
`lean-toolchain`, with Mathlib dependencies/cache available:

```bash
python3 -m pip install -r requirements-checks.txt
bash scripts/check_certificates.sh
```

The `certificate-checks` workflow runs the same command for pull requests and
pushes to `main`. It includes the four certificate packets, runtime regressions,
the anchored Lean proof, independent replays, and the paper-portfolio audit.

To collect timings separately:

```bash
python3 experiments/benchmark_affine_dispatch.py --queries 10000 --repeats 5
```

The benchmark reports setup, validated and raw table-query baselines, memory
estimates, and amortization. A null break-even means the measured verified query
cost offers no sustained advantage over the validated prebuilt table. Timing
values vary by machine and are not correctness gates.

## Check finite controllers

Check safety and recurring progress of a supplied finite controller against a
separately pinned contract, for every possible input sequence:

```bash
python3 scripts/check_controller.py examples/controllers/arbiter.contract.json examples/controllers/arbiter.strategy.json --contract-pin examples/controllers/arbiter.sha256
```

The [controller examples](examples/controllers/README.md) include a fair arbiter,
a delayed acknowledgement service, and unsafe or starving alternatives with
replayable counterexamples. This independently authored tool uses only Python's
standard library. It checks the explicit finite model; Tau translation and
generated-executable verification remain separate work.

The [Tau Net application example](examples/controllers/TAU_NET_APPLICATION.md)
connects the existing finite safety solver to the checker. It generates a
controller that selects one eligible action, then checks all twelve reachable
transitions against a contract frozen before synthesis:

```bash
python3 examples/controllers/synthesize_tau_net_gate.py --output-dir /tmp/orbit-tau-net-gate
```

The selected application scope is solely for Tau Net. This local prototype
does not yet invoke Tau or deploy transactions.

Replay its focused checks with:

```bash
python3 research/prototypes/2026-09-12-strategy-checker/check.py
```

## Portable research plugin

[`plugins/orbitsynthesis-research`](plugins/orbitsynthesis-research) packages the repository's claim ladder as an Agent Plugins 1.0 skill, with a read-only MCP server for inventorying research artifacts and verifying frozen SHA-256 manifests. The server does not execute repository code, write files, access the network, or confer theorem, novelty, publication, or legal authority.

## Living paper drafts

- [`paper/CLONE_CONSTRAINED_SAFETY_DRAFT.md`](paper/CLONE_CONSTRAINED_SAFETY_DRAFT.md) — fixed-algebra term-constrained safety, maximal-domain antichains, and explicit-table initial-set complexity.
- [`paper/FIXED_Q_TERM_COMPLEXITY_DRAFT.md`](paper/FIXED_Q_TERM_COMPLEXITY_DRAFT.md) — exact conservative-term census and shared-DAG Shannon size/depth over the fixed three-element algebra.
- [`paper/ABA_SUPPORT_SYNTHESIS_DRAFT.md`](paper/ABA_SUPPORT_SYNTHESIS_DRAFT.md) — candidate structure-preserving ABA specialization of the public GS/ocLTL framework.

The editorial rules, evidence labels, update gate, and Tau/IP boundaries are in [`paper/PAPER_PORTFOLIO.md`](paper/PAPER_PORTFOLIO.md). Run

```bash
python3 experiments/audit_paper_portfolio.py
```

after changing an authoritative theorem note or receipt. A passing audit detects editorial synchronization only; it is not proof, novelty review, or patent clearance.
